export default function Summary(){
    <>
       <div className="container my-5 p-5">
           <h1 className="my-5 p-5">Summary</h1>
           <p>welcome to my home page</p>
           <p>welcome to my home page</p>
           <p>welcome to my home page</p>
           <p>welcome to my home page</p>
           <p>welcome to my home page</p>
           <p>welcome to my home page</p>
           <p>welcome to my home page</p>
       </div>
    </>
}
export default function Project(){
    <>
       <div className="container my-5 py-5">
           <h1 className="my-5 py-5">Project</h1>
           <p>helllo</p>
           <p>helllo</p>
       </div>
    </>
}
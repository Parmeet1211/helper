import {Link} from 'react-router-dom';

export default function AdminHeader(){
    return(
        <>
            {/* <!-- ======= Header ======= --> */}
            <header id="header" className="fixed-top">
                <div className="container d-flex align-items-center justify-content-between">

                <h1 className="logo"><Link>Helper</Link></h1>                
                

                <nav id="navbar" className="navbar">
                    <ul>
                    <li><Link className="nav-link scrollto " >Home</Link></li>
                    <li><Link className="nav-link scrollto" >About</Link></li>
                    <li><Link className="nav-link scrollto" >Services</Link></li>
                    
                    <li><Link className="nav-link scrollto" >Contact</Link></li>
                    <li><Link className="getstarted scrollto" >Sign In</Link></li>
                    </ul>
                    <i className="bi bi-list mobile-nav-toggle"></i>
                </nav>
                {/* <!-- .navbar --> */}

                </div>
            </header>
            {/* <!-- End Header --> */}
        </>

    )
}
export default function Footer(){
    return(
        <>
            {/* <!-- Footer --> */}
            <footer className="page-footer font-small " style={{backgroundColor:'#dee2e6'}}>

                {/* <!-- Copyright --> */}
                <div className="footer-copyright text-center py-3">© 2023 Copyright:
                    <a href="/"> Parmeet</a>
                </div>
                {/* <!-- Copyright --> */}

            </footer>
            {/* <!-- Footer --> */}
        </>
    )
}
            

    